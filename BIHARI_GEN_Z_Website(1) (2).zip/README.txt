BIHARI GEN Z simple website

Publish:
- Upload index.html to any static hosting service.
- After publishing, share the public website URL.
- For Google Search visibility, submit the public URL in Google Search Console.
